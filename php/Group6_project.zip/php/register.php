<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="icon" href="qiao_logo.svg" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('back_picture.png');
            background-size: 100%;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
        }
        .main-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-container {
            width: 30%;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .register-container h2 {
            margin-top: 0;
        }
        .register-container form input,
        .register-container form select,
        .register-container form button {
            width: 100%;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .register-container button {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .warning {
            color: red;
            font-size: 0.9em;
            display: none;
        }
        .links {
            color: #00aeec;
        }
    </style>
</head>
<body>
<div class="main-container">
    <div class="register-container">
        <h2>Register</h2>
        <form action="new_register.php" id="registerForm" method="post">
            <select name="role" id="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="user">User</option>
                <option value="pharmacy">Pharmacy</option>
            </select>

            <!-- User fields -->
            <div id="userFields" style="display: none;">
                <input type="text" name="u_name" placeholder="Name">
                <input type="text" name="phone" placeholder="Phone Number">
            </div>

            <!-- Pharmacy fields -->
            <div id="pharmacyFields" style="display: none;">
                <input type="text" name="pharmacy_name" placeholder="Pharmacy Name">
                <input type="text" name="pharmacy_address" placeholder="Pharmacy Address">
                <input type="text" name="contact_number" placeholder="Contact Number">
            </div>

            <!-- Common fields -->
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="conf_password" placeholder="Confirm Password" required>
            <div id="passwordWarning" class="warning">Passwords do not match!</div>

            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="login.php" class="links">Login</a></p>
    </div>
</div>

<script>
    const roleSelect = document.getElementById('role');
    const userFields = document.getElementById('userFields');
    const pharmacyFields = document.getElementById('pharmacyFields');

    roleSelect.addEventListener('change', function () {
        if (this.value === 'user') {
            userFields.style.display = 'block';
            pharmacyFields.style.display = 'none';
        } else if (this.value === 'pharmacy') {
            userFields.style.display = 'none';
            pharmacyFields.style.display = 'block';
        } else {
            userFields.style.display = 'none';
            pharmacyFields.style.display = 'none';
        }
    });

    // Password match check
    document.getElementById('registerForm').onsubmit = function (event) {
        const password = document.querySelector('[name="password"]').value;
        const confPassword = document.querySelector('[name="conf_password"]').value;
        const warning = document.getElementById('passwordWarning');

        if (password !== confPassword) {
            warning.style.display = 'block';
            event.preventDefault();
        } else {
            warning.style.display = 'none';
        }
    };
</script>
</body>
</html>
